import * as Icons from '@mui/icons-material';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import SettingsIcon from '@mui/icons-material/Settings';
import { faCalendar } from '@fortawesome/free-regular-svg-icons';



export { Icons, AccountCircleIcon, SettingsIcon,  };