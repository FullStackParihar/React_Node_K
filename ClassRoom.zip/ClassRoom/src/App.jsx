import React from "react";
import HomePage from "./Pages/HomePage";
import InnerPage from "./Pages/InnerPage";
const App = () => {
  return (
    <>
    <div className=""> 
      <InnerPage />
      </div>
    </>
  );
};

export default App;
