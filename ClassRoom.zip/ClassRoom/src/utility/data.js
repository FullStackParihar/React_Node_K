const products = [
    [
        {
          "id": 1,
          "batchName": "Cpp Intermediate 1",
          "organization": "REGex Software",
          "date": null,
          "color": "blue",
          "icon": "R",
          "image": "https://www.gstatic.com/classroom/themes/img_read.jpg"
        },
        {
          "id": 2,
          "batchName": "CPP BATCH - T",
          "organization": "REGex Software",
          "date": null,
          "color": "blue",
          "icon": "R",
          "image": "https://www.gstatic.com/classroom/themes/img_read.jpg"
        },
        {
          "id": 3,
          "batchName": "REACT NODE BATCH",
          "organization": "REGex Software",
          "date": null,
          "color": "green",
          "icon": "R",
          "image": "https://www.gstatic.com/classroom/themes/img_read.jpg"
        },
        {
          "id": 4,
          "batchName": "CPP BATCH S",
          "organization": "REGex Software",
          "date": null,
          "color": "blue",
          "icon": "R",
          "image": "https://www.gstatic.com/classroom/themes/img_read.jpg"
        },
        {
          "id": 5,
          "batchName": "C LOGICAL",
          "organization": "REGex Software",
          "date": "A5",
          "color": "blue",
          "icon": "R",
          "image": "https://www.gstatic.com/classroom/themes/img_read.jpg"
        },
        {
          "id": 6,
          "batchName": "LINUX / GIT",
          "organization": "REGex Software",
          "date": "8 July",
          "color": "green",
          "icon": "R",
          "image": "https://www.gstatic.com/classroom/themes/img_read.jpg"
        }
      ]
      
];

export default products;